const express = require('express');
const cors = require('cors');
const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

const app = express();
const PORT = 3000;

// Middleware to parse JSON bodies
app.use(express.json());
app.use(cors());



// OpenAPI configuration
const swaggerOptions = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'WORDS API',
      version: '1.0.0',
      description: 'A simple Express Words API with OpenAPI documentation',
      contact: {
        name: 'WORDS API Support by OK',
        email: 'support@example.com'
      }
    },
    servers: [
      {
        url: 'http://localhost:3000',
        description: 'WORDS API server'
      }
    ],
    components: {
      schemas: {
        Word: {
          type: 'object',
          required: ['word'],
          properties: {
            id: {
              type: 'integer',
              description: 'Auto-generated word ID',
              example: 1
            },
            word: {
              type: 'string',
              description: 'Word',
              example: 'Alice'
            },            
          }
        },
        Error: {
          type: 'object',
          properties: {
            message: {
              type: 'string',
              example: 'Word not found'
            }
          }
        }
      }
    }
  },
  apis: ['./words-api.js'] // Path to the API routes file
};

const swaggerSpec = swaggerJsdoc(swaggerOptions);

// Swagger UI route
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));



// Sample data (in a real app, this would be a database)
let words = [
  { id: 1, word: 'město' },
  { id: 2, word: 'stopa' },
  { id: 3, word: 'mosty' },
  { id: 4, word: 'lesík' },
  { id: 5, word: 'svíce' },
  { id: 6, word: 'ticho' },
  { id: 7, word: 'smích' },
  { id: 8, word: 'práce' },
  { id: 9, word: 'deník' },
  { id: 10, word: 'rukáv' },
  { id: 11, word: 'karta' },
  { id: 12, word: 'hrady' },
  { id: 13, word: 'život' },
  { id: 14, word: 'kámen' },
  { id: 15, word: 'včela' },
  { id: 16, word: 'nápad' },
  { id: 17, word: 'botka' },
  { id: 18, word: 'listí' },
  { id: 19, word: 'strom' },
  { id: 20, word: 'mozek' },
  { id: 21, word: 'hlína' },
  { id: 22, word: 'kniha' },
  { id: 23, word: 'lampa' },
  { id: 24, word: 'židle' },
  { id: 25, word: 'hrnek' },
  { id: 26, word: 'tužka' },
  { id: 27, word: 'papír' },
  { id: 28, word: 'slovo' },
  { id: 29, word: 'hlava' },
  { id: 30, word: 'srdce' },
  { id: 31, word: 'louka' },
  { id: 32, word: 'tráva' },
  { id: 33, word: 'cesta' },
  { id: 34, word: 'skála' },
  { id: 35, word: 'rybka' },
  { id: 36, word: 'zvíře' },
  { id: 37, word: 'brána' },
  { id: 38, word: 'ulice' },
  { id: 39, word: 'dráha' },
  { id: 40, word: 'perla' },
  { id: 41, word: 'mince' },
  { id: 42, word: 'korál' },
  { id: 43, word: 'mouka' },
  { id: 44, word: 'miska' },
  { id: 45, word: 'talíř' },
  { id: 46, word: 'kobka' },
  { id: 47, word: 'šálek' },
  { id: 48, word: 'láhev' },
  { id: 49, word: 'ploty' },
  { id: 50, word: 'socha' }
];


// Get random Word
/**
 * @swagger
 * /api/words/random:
 *   get:
 *     summary: GET random word
 *     description: Retrieve a random word
 *     tags:
 *       - Words
 *     responses:
 *       200:
 *         description: |
 *           Retrieve a random word
 *
 *             **Example curl command:**
 *             ```bash
 *             curl -X GET http://localhost:3000/api/words/random
 *             ```
 *
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Word'
 */
app.get('/api/words/random', (req, res) => {
	
  const randomIndex = Math.floor(Math.random() * words.length);
  word = words[randomIndex];
  res.json(word);
  
});


// Get all Words
/**
 * @swagger
 * /api/words:
 *   get:
 *     summary: GET list of all words
 *     description: |
 *       Retrieve a list of all words
 *
 *       **Example curl command:**
 *       ```bash
 *       curl -X GET http://localhost:3000/api/words
 *       ```
 *
 *     tags:
 *       - Words
 *     responses:
 *       200:
 *         description: A list of words
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Word'
 */
app.get('/api/words', (req, res) => {
  res.json(words);
});


// GET single word by ID
/**
 * @swagger
 * /api/words/{id}:
 *   get:
 *     summary: Get a word by ID
 *     description: |
 *       Retrieve a single word by their ID
 *
 *       **Example curl command:**
 *       ```bash
 *       curl -X GET http://localhost:3000/api/words/2
 *       ```
 *
 *     tags:
 *       - Words
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Word ID
 *     responses:
 *       200:
 *         description: Word found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Word'
 *       404:
 *         description: Word not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */
app.get('/api/words/:id', (req, res) => {
  const word = words.find(u => u.id === parseInt(req.params.id));
  if (!word) return res.status(404).json({ message: 'Word not found' });
  res.json(word);
});



// POST create new word
/**
 * @swagger
 * /api/words:
 *   post:
 *     summary: Create a new word
 *     description: |
 *       Add a new word to the system
 *
 *       Example curl command:**
 *       ```bash
 *       curl -X POST http://localhost:3000/api/words \
 *         -H "Content-Type: application/json" \
 *         -d '{"name":"Charlie"}'
 *       ```
 *
 *     tags:
 *       - Words
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - word
 *             properties:
 *               word:
 *                 type: string
 *                 example: Charlie
 *     responses:
 *       201:
 *         description: Word created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Word'
 */
app.post('/api/words', (req, res) => {
  const newWord = {
    id: words.length + 1,
    word: req.body.word,
  };
  words.push(newWord);
  res.status(201).json(newWord);
});


// PUT update word
/**
 * @swagger
 * /api/words/{id}:
 *   put:
 *     summary: Update a word
 *     description: |
 *       Update an existing word's information
 *
 *       Example curl command:**
 *       ```bash
 *       curl -X PUT http://localhost:3000/api/words/1 \
 *         -H "Content-Type: application/json" \
 *         -d '{"name":"Alice Updated"}'
 *       ```
 *
 *     tags:
 *       - Words
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Word ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: Alice Updated
 *     responses:
 *       200:
 *         description: Word updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Word'
 *       404:
 *         description: Word not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */
app.put('/api/words/:id', (req, res) => {
  const word = words.find(u => u.id === parseInt(req.params.id));
  if (!word) return res.status(404).json({ message: 'Word not found' });
  
  word.word = req.body.word || word.word;
  res.json(word);
});

// DELETE word
/**
 * @swagger
 * /api/words/{id}:
 *   delete:
 *     summary: Delete a word
 *     description: |
 *        Remove a word from the system
 *
 *        **Example curl command:**
 *          ```bash
 *          curl -X DELETE http://localhost:3000/api/words/23
 *          ```
 *     tags:
 *       - Words
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Word ID
 *     responses:
 *       204:
 *         description: Word deleted successfully
 *       404:
 *         description: Word not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */
app.delete('/api/words/:id', (req, res) => {
  const index = words.findIndex(u => u.id === parseInt(req.params.id));
  if (index === -1) return res.status(404).json({ message: 'Word not found' });
  
  words.splice(index, 1);
  res.status(204).send();
});


// Start server
app.listen(PORT, () => {
  console.log(`Words Server running on http://localhost:${PORT}`);
  console.log(`API Documentation available at http://localhost:${PORT}/api-docs`);
});
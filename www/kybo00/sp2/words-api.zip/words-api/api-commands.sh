

apt install nodejs npm

mkdir words-api
cd words-api
npm init -y
npm install express

npm install swagger-jsdoc swagger-ui-express cors

node .\words-api.js


#Random
curl http://localhost:3000/api/words/random


# Id
curl http://localhost:3000/api/words/2


# New 
curl -X POST http://localhost:3000/api/words \
  -H "Content-Type: application/json" \
  -d '{"word":"Victor"}'

curl -X POST http://localhost:3000/api/words \
  -H "Content-Type: application/json" \
  -d '{"word":"Walter"}'
  
# Update
curl -X PUT http://localhost:3000/api/words/23 \
  -H "Content-Type: application/json" \
  -d '{"word":"WalterU"}'
  
# Delete  
curl -X DELETE http://localhost:3000/api/words/23
  
  
  
#	Victor
#	Walter
#	Xavier
#	Yolanda
#	Zach

# docs

npm install swagger-jsdoc swagger-ui-express
